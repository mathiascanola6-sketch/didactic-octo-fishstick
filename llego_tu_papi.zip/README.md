# Llegó Tu Papi v2

Esta versión conecta la interfaz con la API de OpenAI y permite hacer preguntas de matemáticas y otras asignaturas.

## Ejecutarla en PC

1. Instala Python 3.11 o superior.
2. Abre una terminal dentro de esta carpeta.
3. Ejecuta:
   pip install -r requirements.txt
4. Copia `.env.example` a `.env`.
5. Pon tu clave de API en `OPENAI_API_KEY`.
6. Ejecuta:
   python app.py
7. Abre en el navegador:
   http://localhost:5000

## Importante
No publiques la clave de API dentro de `index.html` ni la compartas. La clave debe permanecer en el servidor, dentro de `.env`.

## Versión web
El mismo proyecto puede ejecutarse en un servidor web que soporte Python/Flask. Configura las variables `OPENAI_API_KEY`, `OPENAI_MODEL` y, si el proveedor lo requiere, `PORT`.

## Qué incluye
- Chat de preguntas y ejercicios.
- Explicaciones paso a paso.
- Adaptación a distintas asignaturas.
- Backend seguro para que la clave no quede expuesta en el navegador.

## Próxima versión
Podemos añadir subida de fotos, lectura de ejercicios mediante visión, PDFs/apuntes, historial y un verificador matemático.
