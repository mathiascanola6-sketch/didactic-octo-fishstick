import os
from flask import Flask, request, jsonify, send_from_directory
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__, static_folder="static")
api_key = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=api_key) if api_key else None

SYSTEM = """Eres Llegó Tu Papi, una profesora virtual paciente y clara.
Tu objetivo es ENSEÑAR, no solo dar respuestas.
Para ejercicios:
1. Identifica la asignatura y el tema.
2. Explica brevemente el concepto necesario.
3. Resuelve paso a paso, sin saltarte pasos importantes.
4. Comprueba el resultado cuando sea posible.
5. Termina con una explicación sencilla.
Si el usuario pide otra asignatura, adapta la explicación.
No inventes datos. Si faltan datos, indícalo.
Usa español claro y formato con títulos y pasos."""

@app.get("/")
def home():
    return send_from_directory("static", "index.html")

@app.post("/api/ask")
def ask():
    if client is None:
        return jsonify({"error": "Falta OPENAI_API_KEY. Configúrala en el archivo .env."}), 500

    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"error": "Escribe un ejercicio o pregunta."}), 400

    try:
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
            instructions=SYSTEM,
            input=question
        )
        return jsonify({"answer": response.output_text})
    except Exception as e:
        return jsonify({"error": f"No se pudo consultar la IA: {e}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
